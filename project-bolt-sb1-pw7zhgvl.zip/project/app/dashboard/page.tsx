'use client';

import { useState } from 'react';
import { ChevronRight, Sparkles, LayoutDashboard, CreditCard, ArrowLeftRight } from 'lucide-react';
import { AccountCard } from '@/components/dashboard/AccountCard';
import { QuickActions } from '@/components/dashboard/QuickActions';
import { TransactionList } from '@/components/dashboard/TransactionList';
import { TransferModal } from '@/components/dashboard/TransferModal';
import { ReceiveModal } from '@/components/dashboard/ReceiveModal';
import { TopUpModal } from '@/components/dashboard/TopUpModal';
import { SpendingStats } from '@/components/dashboard/SpendingStats';
import { CardManager } from '@/components/dashboard/CardManager';
import { useApp } from '@/store/AppContext';

type Tab = 'overview' | 'transactions' | 'card';

const TABS = [
  { key: 'overview' as Tab, label: 'Overview', icon: LayoutDashboard },
  { key: 'transactions' as Tab, label: 'Transactions', icon: ArrowLeftRight },
  { key: 'card' as Tab, label: 'My Card', icon: CreditCard },
];

export default function DashboardPage() {
  const { state } = useApp();
  const [tab, setTab] = useState<Tab>('overview');
  const [transferOpen, setTransferOpen] = useState(false);
  const [receiveOpen, setReceiveOpen] = useState(false);
  const [topUpOpen, setTopUpOpen] = useState(false);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const firstName = state.user?.name?.split(' ')[0] ?? 'there';

  return (
    <>
      <div className="h-full flex flex-col max-w-lg mx-auto w-full px-4 pt-3 pb-2">

        <div className="flex items-center justify-between mb-2.5 flex-shrink-0">
          <div>
            <p className="text-slate-500 text-xs">{greeting},</p>
            <h1 className="text-lg font-bold text-slate-900 leading-tight">{firstName}</h1>
          </div>
          <div className="flex items-center gap-1.5 bg-blue-50 border border-blue-100 rounded-full px-2.5 py-1">
            <Sparkles size={10} className="text-blue-600" />
            <span className="text-[10px] font-semibold text-blue-700">All systems normal</span>
          </div>
        </div>

        <div className="flex-shrink-0 mb-2.5">
          <AccountCard />
        </div>

        <div className="flex bg-slate-100 rounded-xl p-0.5 gap-0.5 mb-2.5 flex-shrink-0">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-[10px] text-[11px] font-semibold transition-all ${
                tab === key
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <Icon size={12} />
              {label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto min-h-0">
          {tab === 'overview' && (
            <div className="space-y-3 pb-2">
              <SpendingStats />

              <div>
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Quick Actions</p>
                <QuickActions
                  onSend={() => setTransferOpen(true)}
                  onReceive={() => setReceiveOpen(true)}
                  onTransactions={() => setTab('transactions')}
                  onTopUp={() => setTopUpOpen(true)}
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Recent Transactions</p>
                  <button
                    onClick={() => setTab('transactions')}
                    className="flex items-center gap-0.5 text-[10px] font-semibold text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    View all
                    <ChevronRight size={11} />
                  </button>
                </div>
                <TransactionList limit={5} showSearch={false} />
              </div>
            </div>
          )}

          {tab === 'transactions' && (
            <div className="pb-2">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">All Transactions</p>
              <TransactionList showSearch={true} />
            </div>
          )}

          {tab === 'card' && (
            <div className="pb-2">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Debit Card</p>
              <CardManager />
            </div>
          )}
        </div>
      </div>

      <TransferModal open={transferOpen} onOpenChange={setTransferOpen} />
      <ReceiveModal open={receiveOpen} onOpenChange={setReceiveOpen} />
      <TopUpModal open={topUpOpen} onOpenChange={setTopUpOpen} />
    </>
  );
}
