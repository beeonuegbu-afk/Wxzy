'use client';

import { useState, useMemo } from 'react';
import { ArrowRight, CircleCheck as CheckCircle2, CircleAlert as AlertCircle, User, FileText, Search, Building2, Globe, ChevronLeft, Clock, Circle as XCircle, Receipt } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { formatCurrency } from '@/lib/formatters';
import { MOCK_RECIPIENTS } from '@/lib/mockData';
import { UK_BANKS, INTL_BANKS, Bank } from '@/lib/banks';
import { TransferOutcome, Receipt as ReceiptType } from '@/lib/types';
import { TransactionReceipt } from './TransactionReceipt';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface TransferModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type Step = 'bank' | 'form' | 'confirm' | 'result' | 'receipt';

const STEP_INDEX: Record<Step, number> = { bank: 0, form: 1, confirm: 2, result: 3, receipt: 3 };
const STEPS: Step[] = ['bank', 'form', 'confirm'];
const STEP_LABELS = ['Bank', 'Details', 'Confirm'];


export function TransferModal({ open, onOpenChange }: TransferModalProps) {
  const { state, transfer } = useApp();
  const [step, setStep] = useState<Step>('bank');
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null);
  const [bankSearch, setBankSearch] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [sortCode, setSortCode] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [iban, setIban] = useState('');
  const outcome: TransferOutcome = 'success';
  const isInternational = selectedBank?.country !== 'United Kingdom';
  const [errorMsg, setErrorMsg] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [receipt, setReceipt] = useState<ReceiptType | null>(null);

  const filteredUK = useMemo(
    () => UK_BANKS.filter((b) => b.name.toLowerCase().includes(bankSearch.toLowerCase())),
    [bankSearch]
  );
  const filteredIntl = useMemo(
    () =>
      INTL_BANKS.filter(
        (b) =>
          b.name.toLowerCase().includes(bankSearch.toLowerCase()) ||
          b.country.toLowerCase().includes(bankSearch.toLowerCase())
      ),
    [bankSearch]
  );

  const suggestions = MOCK_RECIPIENTS.filter(
    (r) => r.toLowerCase().includes(recipientName.toLowerCase()) && recipientName.length > 0
  );

  const amountNum = isNaN(parseFloat(amount)) ? 0 : parseFloat(amount);

  const handleSelectBank = (bank: Bank) => {
    setSelectedBank(bank);
    setStep('form');
  };

  const handleNext = () => {
    if (!recipientName.trim()) { setErrorMsg('Please enter a recipient name.'); return; }
    if (amountNum <= 0) { setErrorMsg('Please enter a valid amount.'); return; }
    if (amountNum > state.balance) {
      setErrorMsg(`Insufficient funds. Available: ${formatCurrency(state.balance)}.`);
      return;
    }
    setErrorMsg('');
    setStep('confirm');
  };

  const handleConfirm = () => {
    const result = transfer({
      recipientName,
      amount: amountNum,
      note,
      outcome,
      bankName: selectedBank?.name ?? 'Unknown Bank',
      bankFlag: selectedBank?.flag ?? '🏦',
    });
    if (result.receipt) setReceipt(result.receipt);
    setStep('result');
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(() => {
      setStep('bank');
      setSelectedBank(null);
      setBankSearch('');
      setRecipientName('');
      setAccountNumber('');
      setSortCode('');
      setAmount('');
      setNote('');
      setIban('');
      setErrorMsg('');
      setReceipt(null);
    }, 300);
  };

  const currentStepIndex = STEP_INDEX[step];

  const resultStatus = receipt?.status ?? 'completed';

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg rounded-3xl border-slate-100 shadow-2xl p-0 overflow-hidden max-h-[92vh] flex flex-col">

        {step !== 'receipt' && (
          <div className="bg-gradient-to-r from-blue-700 to-blue-500 p-5 text-white flex-shrink-0">
            <DialogHeader>
              <div className="flex items-center gap-3">
                {(step === 'form' || step === 'confirm') && (
                  <button
                    onClick={() => setStep(step === 'confirm' ? 'form' : 'bank')}
                    className="w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-500 flex items-center justify-center transition-colors"
                  >
                    <ChevronLeft size={16} className="text-white" />
                  </button>
                )}
                <div>
                  <DialogTitle className="text-white text-xl font-bold leading-none">Send Money</DialogTitle>
                  <p className="text-blue-200 text-xs mt-0.5">
                    {step === 'result'
                      ? 'Transaction complete'
                      : selectedBank
                      ? `via ${selectedBank.name}`
                      : 'Choose a bank to get started'}
                  </p>
                </div>
              </div>
            </DialogHeader>

            {step !== 'result' && (
              <div className="mt-4 flex items-center">
                {STEPS.map((s, i) => (
                  <div key={s} className="flex items-center flex-1 last:flex-none">
                    <div className="flex flex-col items-center gap-1">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          currentStepIndex > i
                            ? 'bg-emerald-400 text-white'
                            : currentStepIndex === i
                            ? 'bg-white text-blue-700'
                            : 'bg-blue-600 text-blue-300'
                        }`}
                      >
                        {currentStepIndex > i ? <CheckCircle2 size={14} /> : i + 1}
                      </div>
                      <span className={`text-xs font-medium ${currentStepIndex === i ? 'text-white' : 'text-blue-300'}`}>
                        {STEP_LABELS[i]}
                      </span>
                    </div>
                    {i < STEPS.length - 1 && (
                      <div
                        className={`flex-1 h-0.5 mx-2 mb-4 rounded transition-colors ${
                          currentStepIndex > i ? 'bg-emerald-400' : 'bg-blue-600'
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="overflow-y-auto flex-1">
          {step === 'bank' && (
            <div className="p-5 space-y-4">
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  placeholder="Search banks or countries..."
                  value={bankSearch}
                  onChange={(e) => setBankSearch(e.target.value)}
                  className="pl-9 rounded-xl border-slate-200 h-10 focus-visible:ring-blue-500 bg-slate-50 text-sm"
                />
              </div>
              {filteredUK.length > 0 && (
                <BankSection title="UK Banks" icon={<Building2 size={14} className="text-blue-600" />} banks={filteredUK} onSelect={handleSelectBank} />
              )}
              {filteredIntl.length > 0 && (
                <BankSection title="International Banks" icon={<Globe size={14} className="text-emerald-600" />} banks={filteredIntl} onSelect={handleSelectBank} />
              )}
              {filteredUK.length === 0 && filteredIntl.length === 0 && (
                <div className="text-center py-10 text-slate-400">
                  <Search size={32} className="mx-auto mb-3 opacity-30" />
                  <p className="text-sm font-medium">No banks found</p>
                  <p className="text-xs text-slate-300 mt-1">Try a different search term</p>
                </div>
              )}
            </div>
          )}

          {step === 'form' && (
            <div className="p-5 space-y-4">
              {selectedBank && (
                <div className={`flex items-center gap-3 p-3 rounded-2xl border border-slate-100 ${selectedBank.bg}`}>
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm border border-slate-100">
                    <span className={`text-xs font-extrabold ${selectedBank.textColor}`}>{selectedBank.shortName.slice(0, 3)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-800 truncate">{selectedBank.name}</p>
                    <p className="text-xs text-slate-400">{selectedBank.flag} {selectedBank.country}</p>
                  </div>
                  <button
                    onClick={() => setStep('bank')}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 bg-white rounded-lg px-2.5 py-1.5 border border-slate-200 transition-colors"
                  >
                    Change
                  </button>
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="text-sm font-semibold text-slate-700">Recipient Name</Label>
                <div className="relative">
                  <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <Input
                    placeholder="Full name of recipient"
                    value={recipientName}
                    onChange={(e) => { setRecipientName(e.target.value); setShowSuggestions(true); }}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
                    className="pl-9 rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500"
                  />
                  {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden z-50">
                      <p className="text-xs text-slate-400 px-3 pt-2 pb-1 font-medium">Recent contacts</p>
                      {suggestions.map((s) => (
                        <button
                          key={s}
                          onMouseDown={() => { setRecipientName(s); setShowSuggestions(false); }}
                          className="w-full text-left px-3 py-2.5 text-sm hover:bg-blue-50 text-slate-700 flex items-center gap-2.5 transition-colors"
                        >
                          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-xs font-bold text-blue-700 flex-shrink-0">
                            {s[0]}
                          </div>
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {isInternational ? (
                <div className="space-y-1.5">
                  <Label className="text-sm font-semibold text-slate-700">IBAN</Label>
                  <Input
                    placeholder="e.g. GB29 NWBK 6016 1331 9268 19"
                    value={iban}
                    onChange={(e) => setIban(e.target.value.toUpperCase().slice(0, 34))}
                    className="rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500 font-mono tracking-wider"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-sm font-semibold text-slate-700">Account Number</Label>
                    <Input
                      placeholder="12345678"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, '').slice(0, 8))}
                      className="rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500 font-mono tracking-wider"
                      inputMode="numeric"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-sm font-semibold text-slate-700">Sort Code</Label>
                    <Input
                      placeholder="20-41-63"
                      value={sortCode}
                      onChange={(e) => {
                        const digits = e.target.value.replace(/\D/g, '').slice(0, 6);
                        const formatted = digits.length <= 2
                          ? digits
                          : digits.length <= 4
                          ? `${digits.slice(0, 2)}-${digits.slice(2)}`
                          : `${digits.slice(0, 2)}-${digits.slice(2, 4)}-${digits.slice(4)}`;
                        setSortCode(formatted);
                      }}
                      className="rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500 font-mono tracking-wider"
                      inputMode="numeric"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="text-sm font-semibold text-slate-700">Amount</Label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-lg">£</span>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="pl-8 rounded-xl border-slate-200 h-12 text-xl font-bold focus-visible:ring-blue-500 text-slate-800"
                    min="0.01"
                    step="0.01"
                  />
                </div>
                <p className="text-xs text-slate-400">
                  Available: <span className="font-semibold text-slate-600">{formatCurrency(state.balance)}</span>
                  <span className="mx-1.5 text-slate-300">·</span>
                  Max: <span className="font-semibold text-slate-600">£50,000</span>
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-semibold text-slate-700">Reference (optional)</Label>
                <div className="relative">
                  <FileText size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <Input
                    placeholder="e.g. Rent, Invoice #123"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="pl-9 rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm">
                  <AlertCircle size={16} className="flex-shrink-0" />
                  {errorMsg}
                </div>
              )}

              <Button onClick={handleNext} className="w-full rounded-xl h-12 bg-blue-600 hover:bg-blue-700 gap-2 text-base font-semibold mt-1">
                Review Transfer <ArrowRight size={17} />
              </Button>
            </div>
          )}

          {step === 'confirm' && (
            <div className="p-5 space-y-4">
              {selectedBank && (
                <div className="flex items-center gap-2.5 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-xl">{selectedBank.flag}</span>
                  <div>
                    <p className="text-xs text-slate-400 font-medium">Sending via</p>
                    <p className="text-sm font-bold text-slate-800">{selectedBank.name}</p>
                  </div>
                </div>
              )}

              <div className="bg-gradient-to-b from-blue-50 to-slate-50 rounded-2xl p-4 border border-slate-100 space-y-3">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Transfer Summary</p>
                <div className="space-y-2.5 pt-1">
                  <SummaryRow label="Recipient" value={recipientName} />
                  <div className="h-px bg-slate-200" />
                  <SummaryRow label="Amount" value={formatCurrency(amountNum)} highlight />
                  <SummaryRow label="Transfer fee" value="Free" success />
                  <div className="h-px bg-slate-200" />
                  <SummaryRow label="Balance after" value={formatCurrency(state.balance - amountNum)} />
                  {note && <SummaryRow label="Reference" value={note} />}
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3.5 bg-amber-50 border border-amber-100 rounded-xl">
                <AlertCircle size={15} className="text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700 leading-relaxed">
                  Verify all details before confirming. Transfers cannot be reversed once submitted.
                </p>
              </div>

              <div className="flex gap-3 pb-1">
                <Button variant="outline" onClick={() => setStep('form')} className="flex-1 rounded-xl h-11 border-slate-200">
                  Back
                </Button>
                <Button onClick={handleConfirm} className="flex-1 rounded-xl h-11 bg-blue-600 hover:bg-blue-700 font-semibold">
                  Confirm Transfer
                </Button>
              </div>
            </div>
          )}

          {step === 'result' && receipt && (
            <div className="p-5 text-center space-y-5 py-8">
              <ResultIcon status={resultStatus} />
              <div>
                <p className="text-xl font-bold text-slate-800">
                  {resultStatus === 'completed' ? 'Transfer Sent!' : resultStatus === 'pending' ? 'Transfer Pending' : 'Transfer Failed'}
                </p>
                <p className="text-slate-500 text-sm mt-1.5">
                  {resultStatus === 'completed' && (
                    <><span className="font-bold text-slate-700">{formatCurrency(amountNum)}</span> sent to <span className="font-semibold text-slate-700">{recipientName}</span></>
                  )}
                  {resultStatus === 'pending' && 'Your transfer is being processed and should arrive within 2 hours.'}
                  {resultStatus === 'failed' && receipt.failureReason}
                </p>
                {selectedBank && <p className="text-xs text-slate-400 mt-0.5">via {selectedBank.name}</p>}
              </div>

              <div className="bg-slate-50 rounded-2xl p-4 text-left space-y-2 border border-slate-100">
                <SummaryRow label="Reference" value={receipt.reference} />
                {resultStatus !== 'failed' && <SummaryRow label="New Balance" value={formatCurrency(receipt.newBalance)} highlight />}
                {resultStatus === 'failed' && <SummaryRow label="Balance" value={formatCurrency(state.balance)} />}
                <SummaryRow
                  label="Status"
                  value={resultStatus === 'completed' ? 'Completed' : resultStatus === 'pending' ? 'Processing' : 'Declined'}
                  success={resultStatus === 'completed'}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep('receipt')}
                  className="flex-1 rounded-xl h-11 border-slate-200 gap-2 font-semibold"
                >
                  <Receipt size={15} />
                  View Receipt
                </Button>
                <Button onClick={handleClose} className="flex-1 rounded-xl h-11 bg-blue-600 hover:bg-blue-700 font-semibold">
                  Done
                </Button>
              </div>
            </div>
          )}

          {step === 'receipt' && receipt && (
            <TransactionReceipt
              receipt={receipt}
              onBack={() => setStep('result')}
              onClose={handleClose}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function BankSection({
  title,
  icon,
  banks,
  onSelect,
}: {
  title: string;
  icon: React.ReactNode;
  banks: Bank[];
  onSelect: (bank: Bank) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 px-1">
        {icon}
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{title}</p>
        <span className="ml-auto text-xs font-semibold text-slate-300">{banks.length} banks</span>
      </div>
      <div className="space-y-1.5">
        {banks.map((bank) => (
          <button
            key={bank.id}
            onClick={() => onSelect(bank)}
            className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 bg-white hover:border-blue-200 hover:bg-blue-50/60 transition-all duration-150 group text-left w-full active:scale-[0.98] shadow-sm"
          >
            <div className={`w-11 h-11 rounded-xl ${bank.bg} flex items-center justify-center flex-shrink-0 border border-slate-100`}>
              <span className={`text-xs font-extrabold tracking-tight ${bank.textColor}`}>{bank.shortName.slice(0, 4)}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800 truncate group-hover:text-blue-700 transition-colors">{bank.name}</p>
              <p className="text-xs text-slate-400 truncate">{bank.flag} {bank.country}</p>
            </div>
            <ArrowRight size={15} className="text-slate-300 group-hover:text-blue-500 flex-shrink-0 transition-all group-hover:translate-x-0.5" />
          </button>
        ))}
      </div>
    </div>
  );
}

function SummaryRow({ label, value, highlight, success }: { label: string; value: string; highlight?: boolean; success?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm text-slate-500">{label}</span>
      <span className={`text-sm font-semibold ${highlight ? 'text-blue-700 text-base' : success ? 'text-emerald-600' : 'text-slate-800'}`}>
        {value}
      </span>
    </div>
  );
}

function ResultIcon({ status }: { status: 'completed' | 'pending' | 'failed' }) {
  const cfg = {
    completed: { icon: CheckCircle2, ringBg: 'bg-emerald-50', ringBorder: 'border-emerald-100', iconClass: 'text-emerald-500' },
    pending: { icon: Clock, ringBg: 'bg-amber-50', ringBorder: 'border-amber-100', iconClass: 'text-amber-500' },
    failed: { icon: XCircle, ringBg: 'bg-red-50', ringBorder: 'border-red-100', iconClass: 'text-red-500' },
  }[status];
  const Icon = cfg.icon;
  return (
    <div className={`w-20 h-20 rounded-full ${cfg.ringBg} border-4 ${cfg.ringBorder} flex items-center justify-center mx-auto`}>
      <Icon size={40} className={cfg.iconClass} />
    </div>
  );
}
