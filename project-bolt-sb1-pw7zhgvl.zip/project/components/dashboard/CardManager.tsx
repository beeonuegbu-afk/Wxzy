'use client';

import { CreditCard, Lock, Eye, EyeOff, Wifi, ShieldAlert, type LucideIcon } from 'lucide-react';
import { useState } from 'react';
import { useApp } from '@/store/AppContext';

export function CardManager() {
  const { state, updateCard } = useApp();
  const [showNumber, setShowNumber] = useState(false);
  const { frozen, contactless, onlinePayments } = state.cardSettings;

  const name = state.user?.name ?? 'Account Holder';
  const maskedNumber = showNumber ? '4929 1842 7731 4291' : '•••• •••• •••• 4291';

  return (
    <div className="space-y-3">
      <div className={`relative w-full rounded-2xl overflow-hidden shadow-lg select-none transition-all duration-500 ${frozen ? 'grayscale opacity-70' : ''}`}>
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #1d4ed8 100%)' }}
        />
        <div
          className="absolute inset-0 opacity-30"
          style={{ backgroundImage: `radial-gradient(circle at 70% 15%, rgba(255,255,255,0.3) 0%, transparent 45%)` }}
        />
        <div className="absolute top-0 right-0 w-36 h-36 rounded-full bg-white/5 -translate-y-1/3 translate-x-1/3" />

        <div className="relative px-4 pt-4 pb-3 text-white z-10">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-blue-200 text-[9px] font-medium uppercase tracking-widest mb-0.5">Debit Card</p>
              <p className="text-white/90 font-semibold text-sm">{name}</p>
            </div>
            <Wifi size={14} className="text-white/60 rotate-90 mt-0.5" />
          </div>

          <div className="mb-4">
            <div className="flex items-center gap-2">
              <p className="font-mono text-sm font-semibold tracking-widest">{maskedNumber}</p>
              <button
                onClick={() => setShowNumber(!showNumber)}
                className="p-1 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                {showNumber ? <EyeOff size={12} /> : <Eye size={12} />}
              </button>
            </div>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <p className="text-blue-200 text-[9px] uppercase tracking-widest mb-0.5">Expires</p>
              <p className="font-mono text-xs font-medium">09 / 28</p>
            </div>
            <div className="text-right">
              <p className="text-blue-200 text-[9px] uppercase tracking-widest mb-0.5">CVV</p>
              <p className="font-mono text-xs font-medium">{showNumber ? '382' : '•••'}</p>
            </div>
            <div className="flex -space-x-1.5">
              <div className="w-6 h-6 rounded-full bg-yellow-400/80 border-2 border-blue-700" />
              <div className="w-6 h-6 rounded-full bg-orange-500/80 border-2 border-blue-700" />
            </div>
          </div>
        </div>

        {frozen && (
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-xl px-3 py-1.5">
              <Lock size={13} className="text-white" />
              <span className="text-white font-bold text-xs">Card Frozen</span>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="px-3 py-2 border-b border-slate-50">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Card Controls</p>
        </div>

        <div className="divide-y divide-slate-50">
          <ToggleRow
            icon={frozen ? ShieldAlert : CreditCard}
            iconBg={frozen ? 'bg-rose-50' : 'bg-blue-50'}
            iconColor={frozen ? 'text-rose-500' : 'text-blue-600'}
            label={frozen ? 'Card Frozen' : 'Card Active'}
            desc={frozen ? 'Tap to unfreeze your card' : 'Temporarily freeze your card'}
            value={!frozen}
            onToggle={() => updateCard({ frozen: !frozen })}
            danger={frozen}
          />
          <ToggleRow
            icon={Wifi}
            iconBg="bg-emerald-50"
            iconColor="text-emerald-600"
            label="Contactless Payments"
            desc="Pay with tap at terminals"
            value={contactless}
            onToggle={() => updateCard({ contactless: !contactless })}
          />
          <ToggleRow
            icon={ShieldAlert}
            iconBg="bg-amber-50"
            iconColor="text-amber-500"
            label="Online Payments"
            desc="Use card on websites and apps"
            value={onlinePayments}
            onToggle={() => updateCard({ onlinePayments: !onlinePayments })}
          />
        </div>
      </div>
    </div>
  );
}

function ToggleRow({
  icon: Icon,
  iconBg,
  iconColor,
  label,
  desc,
  value,
  onToggle,
  danger,
}: {
  icon: LucideIcon;
  iconBg: string;
  iconColor: string;
  label: string;
  desc: string;
  value: boolean;
  onToggle: () => void;
  danger?: boolean;
}) {
  return (
    <div className="flex items-center gap-3 px-3 py-3">
      <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center flex-shrink-0`}>
        <Icon size={14} className={iconColor} />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-semibold ${danger ? 'text-rose-600' : 'text-slate-800'}`}>{label}</p>
        <p className="text-[10px] text-slate-400">{desc}</p>
      </div>
      <button
        onClick={onToggle}
        className={`relative w-10 h-5 rounded-full transition-colors flex-shrink-0 ${
          value ? (danger ? 'bg-rose-500' : 'bg-blue-600') : 'bg-slate-200'
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${
            value ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}
