'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Bell, LogOut, Settings, Headphones as HeadphonesIcon } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { NotificationsPanel } from '@/components/dashboard/NotificationsPanel';
import { SettingsModal } from '@/components/dashboard/SettingsModal';
import { SupportModal } from '@/components/dashboard/SupportModal';

const INITIAL_UNREAD = 2;

export function Header() {
  const { state, logout } = useApp();
  const router = useRouter();
  const [notifOpen, setNotifOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(INITIAL_UNREAD);

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const initials = state.user?.avatarInitials ?? 'U';

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-100 shadow-sm">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/images_(1).png" alt="Halifax" className="h-8 w-auto object-contain" />
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSupportOpen(true)}
              className="relative text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
              title="Contact Support"
            >
              <HeadphonesIcon size={18} />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setNotifOpen(true)}
              className="relative text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
              title="Notifications"
            >
              <Bell size={18} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 min-w-[16px] h-4 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-[9px] font-bold leading-none px-0.5">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                </span>
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2.5 pl-1 pr-3 py-1.5 rounded-2xl hover:bg-slate-100 transition-colors">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-sm">
                    <span className="text-white font-semibold text-xs">{initials}</span>
                  </div>
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-semibold text-slate-800 leading-tight">{state.user?.name ?? 'User'}</p>
                    <p className="text-xs text-slate-500 leading-tight">Personal Account</p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52 rounded-2xl shadow-xl border-slate-100 p-1.5">
                <div className="px-3 py-2 mb-1">
                  <p className="text-sm font-semibold text-slate-800">{state.user?.name ?? 'User'}</p>
                  <p className="text-xs text-slate-500">{state.user?.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSettingsOpen(true)}
                  className="rounded-xl cursor-pointer text-slate-600 hover:text-slate-900 hover:bg-slate-50 gap-2.5"
                >
                  <Settings size={15} />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setSupportOpen(true)}
                  className="rounded-xl cursor-pointer text-slate-600 hover:text-slate-900 hover:bg-slate-50 gap-2.5"
                >
                  <HeadphonesIcon size={15} />
                  Contact Support
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleLogout}
                  className="rounded-xl cursor-pointer text-red-500 hover:text-red-600 hover:bg-red-50 gap-2.5"
                >
                  <LogOut size={15} />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <NotificationsPanel
        open={notifOpen}
        onOpenChange={setNotifOpen}
        onUnreadChange={setUnreadCount}
      />
      <SettingsModal open={settingsOpen} onOpenChange={setSettingsOpen} />
      <SupportModal open={supportOpen} onOpenChange={setSupportOpen} />
    </>
  );
}
