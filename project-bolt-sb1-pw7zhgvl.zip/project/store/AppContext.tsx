'use client';

import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { AppState, CardSettings, Transaction, TransferPayload, Receipt } from '@/lib/types';
import { loadState, saveState, clearState, initializeStateWithUser } from '@/lib/storage';
import { generateReference } from '@/lib/formatters';

type Action =
  | { type: 'LOGIN'; email: string }
  | { type: 'LOGOUT' }
  | { type: 'TRANSFER'; payload: TransferPayload }
  | { type: 'TOPUP'; amount: number; reference: string }
  | { type: 'UPDATE_CARD'; settings: Partial<CardSettings> }
  | { type: 'HYDRATE'; state: AppState };

interface AppContextValue {
  state: AppState;
  login: (email: string, password: string) => void;
  logout: () => void;
  transfer: (payload: TransferPayload) => { success: boolean; message: string; receipt?: Receipt };
  topUp: (amount: number, reference: string) => void;
  updateCard: (settings: Partial<CardSettings>) => void;
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'HYDRATE':
      return action.state;

    case 'LOGIN': {
      const newState = initializeStateWithUser(action.email);
      return newState;
    }

    case 'UPDATE_CARD':
      return { ...state, cardSettings: { ...state.cardSettings, ...action.settings } };

    case 'LOGOUT':
      return {
        user: null,
        isAuthenticated: false,
        balance: state.balance,
        transactions: state.transactions,
        cardSettings: state.cardSettings,
      };

    case 'TOPUP': {
      const topUpTx: Transaction = {
        id: Math.random().toString(36).slice(2, 11).toUpperCase(),
        type: 'credit',
        amount: action.amount,
        description: 'Account Top-Up',
        recipient: 'Halifax Digital Bank',
        category: 'transfer',
        timestamp: new Date().toISOString(),
        status: 'completed',
        reference: action.reference,
      };
      return {
        ...state,
        balance: parseFloat((state.balance + action.amount).toFixed(2)),
        transactions: [topUpTx, ...state.transactions],
      };
    }

    case 'TRANSFER': {
      const { recipientName, amount, note, outcome = 'success' } = action.payload;
      const txStatus = outcome === 'success' ? 'completed' : outcome === 'pending' ? 'pending' : 'failed';
      const newTransaction: Transaction = {
        id: Math.random().toString(36).slice(2, 11).toUpperCase(),
        type: 'debit',
        amount,
        description: note || `Transfer to ${recipientName}`,
        recipient: recipientName,
        category: 'transfer',
        timestamp: new Date().toISOString(),
        status: txStatus,
        reference: 'TRF-' + generateReference(),
      };
      const balanceDeducted = outcome !== 'failed';
      return {
        ...state,
        balance: balanceDeducted ? parseFloat((state.balance - amount).toFixed(2)) : state.balance,
        transactions: [newTransaction, ...state.transactions],
      };
    }

    default:
      return state;
  }
}

const defaultCardSettings = { frozen: false, contactless: true, onlinePayments: true };

const defaultState: AppState = {
  user: null,
  isAuthenticated: false,
  balance: 340000,
  transactions: [],
  cardSettings: defaultCardSettings,
};

const AppContext = createContext<AppContextValue>({
  state: defaultState,
  login: () => {},
  logout: () => {},
  transfer: () => ({ success: false, message: '' }),
  topUp: () => {},
  updateCard: () => {},
});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, defaultState);

  useEffect(() => {
    const saved = loadState();
    dispatch({ type: 'HYDRATE', state: saved });
  }, []);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const login = useCallback((email: string, _password: string) => {
    dispatch({ type: 'LOGIN', email });
  }, []);

  const logout = useCallback(() => {
    clearState();
    dispatch({ type: 'LOGOUT' });
  }, []);

  const topUp = useCallback((amount: number, reference: string) => {
    dispatch({ type: 'TOPUP', amount, reference });
  }, []);

  const updateCard = useCallback((settings: Partial<CardSettings>) => {
    dispatch({ type: 'UPDATE_CARD', settings });
  }, []);

  const transfer = useCallback(
    (payload: TransferPayload): { success: boolean; message: string; receipt?: Receipt } => {
      if (payload.amount <= 0) {
        return { success: false, message: 'Amount must be greater than zero.' };
      }
      if (payload.amount > state.balance) {
        return { success: false, message: 'Insufficient funds for this transfer.' };
      }
      if (!payload.recipientName.trim()) {
        return { success: false, message: 'Recipient name is required.' };
      }
      if (payload.amount > 50000) {
        return { success: false, message: 'Transfer limit is £50,000 per transaction.' };
      }

      const outcome = payload.outcome ?? 'success';
      const txStatus = outcome === 'success' ? 'completed' : outcome === 'pending' ? 'pending' : 'failed';
      const reference = 'TRF-' + generateReference();
      const newBalance = outcome !== 'failed'
        ? parseFloat((state.balance - payload.amount).toFixed(2))
        : state.balance;

      const failureReasons: Record<string, string> = {
        failed: 'Transaction declined by the receiving bank. Please verify recipient details.',
      };

      const receipt: Receipt = {
        id: Math.random().toString(36).slice(2, 11).toUpperCase(),
        status: txStatus,
        recipientName: payload.recipientName,
        amount: payload.amount,
        note: payload.note ?? '',
        bankName: payload.bankName ?? 'Unknown Bank',
        bankFlag: payload.bankFlag ?? '🏦',
        reference,
        timestamp: new Date().toISOString(),
        senderName: state.user?.name ?? 'Account Holder',
        senderAccount: state.user?.accountNumber ?? '****0000',
        senderSortCode: state.user?.sortCode ?? '**-**-**',
        newBalance,
        failureReason: outcome === 'failed' ? failureReasons.failed : undefined,
      };

      dispatch({ type: 'TRANSFER', payload: { ...payload, outcome } });
      return {
        success: outcome !== 'failed',
        message: outcome === 'success'
          ? 'Transfer completed successfully.'
          : outcome === 'pending'
          ? 'Transfer is being processed.'
          : 'Transfer was declined.',
        receipt,
      };
    },
    [state.balance, state.user]
  );

  return (
    <AppContext.Provider value={{ state, login, logout, transfer, topUp, updateCard }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
